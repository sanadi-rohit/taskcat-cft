AWS Quick Start: CI/CD Pipeline for AWS CloudFormation Templates Using TaskCat -- Deployment Guide

Official repository of the deployment guide (https://docs.aws.amazon.com/quickstart/latest/cicd-taskcat/)

## License Summary

The documentation is made available under the Creative Commons Attribution-ShareAlike 4.0 International License. See the LICENSE file.

The sample code within this documentation is made available under a modified MIT license. See the LICENSE-SAMPLECODE file.
