# Step 1\. Prepare Your AWS Account<a name="step1"></a>

****

1.  If you don’t already have an AWS account, create one at [https://aws\.amazon\.com](https://aws.amazon.com) by following the on\-screen instructions\. 

1.  Use the region selector in the navigation bar to choose the AWS Region where you want to deploy CI/CD pipeline for AWS CloudFormation templates on AWS\. 